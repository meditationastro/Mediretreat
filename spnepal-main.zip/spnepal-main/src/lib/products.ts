// Product data structure with full details
export interface Product {
    id: string;
    slug: string;
    name: string;
    price: number;
    category: string;
    shortDescription: string;
    fullDescription: string;
    features: string[];
    specifications?: { label: string; value: string }[];
    image: string;
    featured?: boolean;
    inStock: boolean;
}

export const products: Product[] = [
    {
        id: '1',
        slug: 'himalayan-meditation-mala',
        name: 'Himalayan Meditation Mala',
        price: 45,
        category: 'Meditation Tools',
        shortDescription: 'Hand-knotted 108 bead mala made with sacred Rudraksha seeds from the Himalayas.',
        fullDescription: `This authentic Himalayan Meditation Mala is crafted with 108 sacred Rudraksha seeds, hand-selected from the foothills of the Himalayas in Nepal. Each bead has been traditionally blessed and strung with silk thread using ancient knotting techniques passed down through generations.

Rudraksha beads are revered in Hindu and Buddhist traditions for their spiritual power and healing properties. The name comes from "Rudra" (another name for Lord Shiva) and "Aksha" (eyes), meaning "the eyes of Shiva."

This mala is perfect for japa meditation, mantra recitation, and daily spiritual practice. The 108 beads represent the 108 earthly desires one must overcome to achieve enlightenment, making each round of the mala a complete cycle of mindful awareness.`,
        features: [
            '108 authentic Rudraksha beads',
            'Hand-knotted with silk thread',
            'Traditional Himalayan craftsmanship',
            'Includes guru bead and tassel',
            'Blessed by Nepali monks',
            'Comes with cotton storage pouch',
        ],
        specifications: [
            { label: 'Bead Size', value: '8mm' },
            { label: 'Total Length', value: '42 inches' },
            { label: 'Material', value: 'Rudraksha seeds, Silk thread' },
            { label: 'Origin', value: 'Nepal' },
        ],
        image: '◯',
        featured: true,
        inStock: true,
    },
    {
        id: '2',
        slug: 'tibetan-singing-bowl-set',
        name: 'Tibetan Singing Bowl Set',
        price: 85,
        category: 'Meditation Tools',
        shortDescription: 'Authentic hand-hammered singing bowl with wooden mallet and cushion.',
        fullDescription: `Experience the profound vibrations of this authentic Tibetan Singing Bowl, hand-hammered by skilled artisans in the Kathmandu Valley using techniques unchanged for centuries.

The rich, harmonic tones produced by this bowl are used for meditation, healing, and cleansing spaces of negative energy. When played, the bowl creates a symphony of overtones that promote deep relaxation and help quiet the mind.

Each bowl is unique, hammered from a traditional alloy of seven metals corresponding to the seven chakras and seven celestial bodies of ancient astrology. The imperfections in the surface are testament to its handcrafted authenticity.

This complete set includes everything you need to begin your sound healing journey: the singing bowl, a hand-turned wooden mallet wrapped with suede, and a cushion to rest the bowl during use.`,
        features: [
            'Hand-hammered by Nepali artisans',
            'Traditional seven-metal alloy',
            'Includes wooden mallet with suede wrap',
            'Includes ring cushion',
            'Rich, sustained resonance',
            'Perfect for meditation and sound healing',
        ],
        specifications: [
            { label: 'Diameter', value: '5 inches' },
            { label: 'Weight', value: '400g' },
            { label: 'Material', value: 'Seven-metal bronze alloy' },
            { label: 'Origin', value: 'Kathmandu, Nepal' },
        ],
        image: '✧',
        inStock: true,
    },
    {
        id: '3',
        slug: 'clear-quartz-crystal-point',
        name: 'Clear Quartz Crystal Point',
        price: 35,
        category: 'Crystals',
        shortDescription: 'Natural clear quartz crystal for clarity, amplification, and healing energy.',
        fullDescription: `This stunning natural Clear Quartz Crystal Point is hand-selected for its exceptional clarity and energy. Known as the "Master Healer," clear quartz is one of the most versatile and powerful crystals in the mineral kingdom.

Clear quartz amplifies energy and intention, making it an essential tool for meditation, healing work, and manifestation practices. It can be programmed with any intention and will continue to broadcast that energy.

In Vedic traditions, clear quartz is associated with all seven chakras, particularly the crown chakra, helping to open channels to higher consciousness and spiritual awareness.

Each crystal is unique with its own natural formations, inclusions, and energy signature. Your crystal will be intuitively selected and cleansed before shipping.`,
        features: [
            'Natural, unpolished crystal point',
            'Exceptional optical clarity',
            'Amplifies intentions and energy',
            'Suitable for all chakra work',
            'Cleansed and charged before shipping',
            'Comes with care instructions',
        ],
        specifications: [
            { label: 'Height', value: '2-3 inches' },
            { label: 'Weight', value: '50-80g' },
            { label: 'Type', value: 'Natural point' },
            { label: 'Origin', value: 'Brazil' },
        ],
        image: '◇',
        inStock: true,
    },
    {
        id: '4',
        slug: 'amethyst-cluster',
        name: 'Amethyst Cluster',
        price: 55,
        category: 'Crystals',
        shortDescription: 'Beautiful purple amethyst cluster for spiritual protection and intuition.',
        fullDescription: `This magnificent Amethyst Cluster displays the deep purple hues that have made amethyst a prized spiritual stone for millennia. The cluster formation features multiple crystal points growing together, creating a powerful energy generator.

Amethyst is known as the stone of spiritual protection and purification. It creates a bubble of protective light around the aura and helps transmute negative energy into love. The crystal is particularly effective for enhancing intuition, calming the mind, and promoting restful sleep.

In Vedic astrology, amethyst is associated with Saturn and is recommended for strengthening spiritual practices and developing higher consciousness. It resonates strongly with the third eye and crown chakras.

Each cluster is a unique natural formation, millions of years in the making. Display it in your meditation space, bedroom, or anywhere you wish to promote calm and spiritual clarity.`,
        features: [
            'Natural cluster formation',
            'Deep purple coloration',
            'Multiple crystal points',
            'Promotes spiritual protection',
            'Enhances intuition and meditation',
            'Perfect for home altar or sacred space',
        ],
        specifications: [
            { label: 'Size', value: '3-4 inches' },
            { label: 'Weight', value: '200-350g' },
            { label: 'Grade', value: 'A Quality' },
            { label: 'Origin', value: 'Uruguay' },
        ],
        image: '❋',
        inStock: true,
    },
    {
        id: '5',
        slug: 'creator-of-universe-ebook',
        name: 'The Creator of the Universe (eBook)',
        price: 15,
        category: 'Digital Products',
        shortDescription: 'A comprehensive guide to understanding your spiritual journey by Dinesh.',
        fullDescription: `"The Creator of the Universe" is a profound exploration of Vedic philosophy, consciousness, and the nature of reality, written by Dinesh from years of study and spiritual practice in the Himalayan tradition.

This comprehensive guide bridges ancient wisdom with modern understanding, offering practical insights for those seeking to understand their place in the cosmic order. Drawing from the Upanishads, Bhagavad Gita, and tantric traditions, the book presents complex philosophical concepts in accessible language.

Topics covered include:
- The nature of Brahman and individual consciousness
- Understanding karma and its role in spiritual evolution  
- The science of meditation and its effects on the mind
- Practical techniques for self-realization
- Integration of spiritual practice in daily life

Whether you are new to Vedic philosophy or a seasoned practitioner, this book offers fresh perspectives and practical wisdom for your spiritual journey.`,
        features: [
            'PDF format, readable on any device',
            'Over 200 pages of content',
            'Includes practical exercises',
            'Illustrated with traditional artwork',
            'Instant download after purchase',
            'Lifetime access to updates',
        ],
        specifications: [
            { label: 'Format', value: 'PDF' },
            { label: 'Pages', value: '220' },
            { label: 'Language', value: 'English' },
            { label: 'Author', value: 'Dinesh' },
        ],
        image: '📖',
        featured: true,
        inStock: true,
    },
    {
        id: '6',
        slug: 'vedic-astrology-basics-course',
        name: 'Vedic Astrology Basics Course',
        price: 99,
        category: 'Digital Products',
        shortDescription: 'Learn the ancient wisdom of Jyotish with this comprehensive video course.',
        fullDescription: `Embark on a transformative journey into the ancient science of Vedic Astrology (Jyotish) with this comprehensive video course designed for beginners and intermediate students.

Taught by Dinesh, a practicing Vedic astrologer with decades of experience, this course takes you step-by-step through the fundamentals of reading and interpreting birth charts according to the Parashari system.

The course includes:
- Understanding the 12 signs (Rashis) and their qualities
- Deep dive into the 9 planets (Navagraha) and their significations
- The 12 houses (Bhavas) and their meanings
- Planetary aspects, conjunctions, and yogas
- Introduction to the Dasha system for timing
- Practical chart reading exercises

By the end of this course, you will be able to read your own birth chart and gain insights into your life patterns, karmic themes, and spiritual path.`,
        features: [
            '15+ hours of video content',
            'Downloadable course materials',
            'Practice charts and exercises',
            'Certificate of completion',
            'Access to student community',
            'Lifetime access',
        ],
        specifications: [
            { label: 'Duration', value: '15 hours' },
            { label: 'Lessons', value: '45 videos' },
            { label: 'Language', value: 'English' },
            { label: 'Level', value: 'Beginner to Intermediate' },
        ],
        image: '✦',
        inStock: true,
    },
    {
        id: '7',
        slug: 'birth-chart-analysis-template',
        name: 'Birth Chart Analysis Template',
        price: 25,
        category: 'Astrology Tools',
        shortDescription: 'Printable Janma Kundali template with detailed house interpretations.',
        fullDescription: `This beautifully designed Birth Chart Analysis Template is an essential tool for anyone studying or practicing Vedic Astrology. The printable template allows you to draw and analyze birth charts by hand, deepening your connection to the ancient art of Jyotish.

The template includes:
- Traditional South Indian and North Indian chart formats
- Detailed interpretations for all 12 houses
- Quick-reference guides for planetary dignities
- Aspect calculation worksheets
- Dasha calculation tables
- Notes sections for your observations

Learning to draw charts by hand is a time-honored practice that helps astrologers internalize planetary positions and develop intuitive understanding. This template makes the process structured and meaningful.`,
        features: [
            'Both South Indian and North Indian formats',
            'High-quality printable PDF',
            'Detailed house significations included',
            'Planetary dignity reference tables',
            'Space for notes and observations',
            'Unlimited prints for personal use',
        ],
        specifications: [
            { label: 'Format', value: 'PDF (A4 size)' },
            { label: 'Pages', value: '12' },
            { label: 'Chart Styles', value: 'South Indian, North Indian' },
            { label: 'Print Quality', value: '300 DPI' },
        ],
        image: '△',
        inStock: true,
    },
    {
        id: '8',
        slug: 'panchang-calendar-2026',
        name: 'Panchang Calendar 2026',
        price: 20,
        category: 'Astrology Tools',
        shortDescription: 'Traditional Vedic calendar with tithis, nakshatras, and auspicious timings.',
        fullDescription: `The Panchang Calendar 2026 is your comprehensive guide to Vedic timekeeping, offering all the essential information you need to plan activities according to auspicious cosmic timings.

Panchang, meaning "five limbs," refers to the five elements of the Vedic calendar: Tithi (lunar day), Vara (weekday), Nakshatra (lunar mansion), Yoga (lunar-solar combination), and Karana (half lunar day). Understanding these elements helps you align your activities with cosmic rhythms.

This beautifully designed calendar includes:
- Daily tithi and nakshatra information
- Festival and holy day listings
- Ekadashi fasting dates
- Eclipse information
- Planetary transit dates
- Muhurta (auspicious timing) guidelines

Whether planning important events, scheduling spiritual practices, or simply living in harmony with natural cycles, this calendar is an indispensable tool.`,
        features: [
            'Complete 2026 Vedic calendar',
            'Daily tithi and nakshatra listings',
            'All major Hindu festivals',
            'Eclipse dates and timings',
            'Auspicious muhurta guidelines',
            'Beautiful traditional design',
        ],
        specifications: [
            { label: 'Year', value: '2026' },
            { label: 'Format', value: 'PDF' },
            { label: 'Pages', value: '52 (weekly spreads)' },
            { label: 'Timezone', value: 'Nepal Standard Time' },
        ],
        image: '◎',
        inStock: true,
    },
    {
        id: '9',
        slug: 'meditation-for-beginners-book',
        name: 'Meditation for Beginners (Book)',
        price: 22,
        category: 'Books',
        shortDescription: 'A gentle introduction to meditation practices rooted in Himalayan wisdom.',
        fullDescription: `"Meditation for Beginners" is a gentle, accessible guide to establishing a sustainable meditation practice rooted in the authentic wisdom of the Himalayan tradition.

Written with the modern seeker in mind, this book addresses common challenges faced by beginners, including restless mind, physical discomfort, and finding time for practice. Each chapter builds progressively, starting with simple breath awareness and culminating in deeper contemplative techniques.

The book covers:
- Setting up your meditation space
- Proper sitting postures for comfort
- Breath-based meditation techniques
- Mantra meditation basics
- Working with thoughts and emotions
- Integrating meditation into daily life

Illustrated with simple diagrams and featuring guided practices you can follow, this book provides everything a beginner needs to start their meditation journey with confidence.`,
        features: [
            'Written for complete beginners',
            'Step-by-step progressive approach',
            'Illustrated posture guides',
            'Multiple meditation techniques',
            'Troubleshooting common challenges',
            'Daily practice schedules',
        ],
        specifications: [
            { label: 'Format', value: 'Paperback' },
            { label: 'Pages', value: '156' },
            { label: 'Language', value: 'English' },
            { label: 'Author', value: 'Dinesh' },
        ],
        image: '📚',
        inStock: true,
    },
    {
        id: '10',
        slug: 'sandalwood-incense-bundle',
        name: 'Sandalwood Incense Bundle',
        price: 12,
        category: 'Meditation Tools',
        shortDescription: 'Premium hand-rolled sandalwood incense sticks from Nepal.',
        fullDescription: `Transform your meditation space with the sacred fragrance of authentic Nepali Sandalwood Incense. Each stick is hand-rolled using traditional methods passed down through generations of incense makers in the Kathmandu Valley.

Made with pure sandalwood powder, natural resins, and Himalayan herbs, these incense sticks burn cleanly and release a rich, woody fragrance that calms the mind and prepares the consciousness for meditation.

Sandalwood has been used in Hindu and Buddhist rituals for thousands of years. Its cooling, grounding scent is believed to open the third eye, enhance spiritual awareness, and create a sacred atmosphere for prayer and contemplation.

Unlike synthetic incense, our hand-rolled sticks contain no artificial fragrances, dyes, or chemical binders. They burn slowly and evenly, filling your space with pure, natural scent.`,
        features: [
            'Hand-rolled in Nepal',
            '100% natural ingredients',
            'Pure sandalwood and Himalayan herbs',
            'No artificial fragrances or dyes',
            'Approximately 40 sticks per bundle',
            'Burns for 45-60 minutes per stick',
        ],
        specifications: [
            { label: 'Quantity', value: '40 sticks' },
            { label: 'Length', value: '9 inches' },
            { label: 'Burn Time', value: '45-60 minutes' },
            { label: 'Origin', value: 'Kathmandu, Nepal' },
        ],
        image: '✿',
        inStock: true,
    },
];

// Helper to get product by slug
export function getProductBySlug(slug: string): Product | undefined {
    return products.find(p => p.slug === slug);
}

// Helper to get related products
export function getRelatedProducts(product: Product, limit: number = 3): Product[] {
    return products
        .filter(p => p.id !== product.id && p.category === product.category)
        .slice(0, limit);
}

// Categories
export const categories = [
    'All Products',
    'Meditation Tools',
    'Crystals',
    'Books',
    'Digital Products',
    'Astrology Tools',
];
