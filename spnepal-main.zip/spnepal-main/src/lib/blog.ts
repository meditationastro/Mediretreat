// Blog post data structure
export interface BlogPost {
    id: string;
    title: string;
    slug: string;
    excerpt: string;
    content: string;
    author: string;
    date: string;
    readTime: string;
    category: string;
    published: boolean;
}

// Default blog posts
export const defaultPosts: BlogPost[] = [
    {
        id: '1',
        title: 'Understanding Your Vedic Birth Chart',
        slug: 'understanding-your-vedic-birth-chart',
        excerpt: 'Discover how the ancient science of Jyotish can reveal your life purpose, strengths, and karmic patterns through your unique birth chart.',
        content: `# Understanding Your Vedic Birth Chart

Your Vedic birth chart, or Janma Kundali, is a celestial snapshot of the sky at the exact moment of your birth. Unlike Western astrology, Vedic astrology (Jyotish) uses the sidereal zodiac, which accounts for the precession of the equinoxes.

## The Nine Planets (Navagraha)

In Vedic astrology, we work with nine celestial bodies:
- **Sun (Surya)** - Soul, vitality, father
- **Moon (Chandra)** - Mind, emotions, mother
- **Mars (Mangal)** - Energy, courage, siblings
- **Mercury (Budha)** - Intellect, communication
- **Jupiter (Guru)** - Wisdom, expansion, teachers
- **Venus (Shukra)** - Love, beauty, creativity
- **Saturn (Shani)** - Discipline, karma, longevity
- **Rahu** - Desires, ambition, worldly attachments
- **Ketu** - Spirituality, liberation, past life karma

## The Twelve Houses (Bhavas)

Each house in your chart governs specific life areas. Understanding which planets occupy and aspect these houses reveals your life patterns.

## Getting Started

To begin your journey with Vedic astrology, you'll need:
1. Your exact birth date
2. Your exact birth time
3. Your birth location

With this information, we can create your personalized birth chart and begin uncovering the cosmic wisdom it holds for your life path.

🙏 Namaste`,
        author: 'Dinesh',
        date: 'January 8, 2026',
        readTime: '5 min read',
        category: 'Vedic Astrology',
        published: true,
    },
    {
        id: '2',
        title: 'The Power of a Morning Meditation Ritual',
        slug: 'morning-meditation-ritual',
        excerpt: 'Learn how starting your day with mindful meditation can transform your energy, focus, and overall well-being.',
        content: `# The Power of a Morning Meditation Ritual

The early morning hours, known as Brahma Muhurta (approximately 4:00-6:00 AM), are considered the most auspicious time for spiritual practice.

## Why Morning Meditation?

During these hours:
- The mind is naturally calm and receptive
- Environmental disturbances are minimal
- Prana (life force) flows most freely
- The veil between conscious and unconscious is thin

## A Simple Morning Practice

### 1. Wake Before Sunrise
Try to rise during Brahma Muhurta when cosmic energy is at its peak.

### 2. Cleanse and Prepare
Wash your face, brush your teeth, and drink warm water to awaken your system.

### 3. Find Your Seat
Choose a clean, quiet space. Sit on a cushion or mat facing east.

### 4. Begin with Pranayama
Start with 5-10 rounds of alternate nostril breathing (Nadi Shodhana) to balance your energy channels.

### 5. Settle into Stillness
Allow your breath to become natural. Observe without controlling.

### 6. Use a Mantra (Optional)
If your mind wanders, silently repeat "So Ham" (I am That) or another mantra given by your teacher.

### 7. Close with Gratitude
End your practice by thanking the cosmic source for this new day.

Even 10-15 minutes each morning can profoundly shift your consciousness over time.

🕉️ Om Shanti`,
        author: 'Dinesh',
        date: 'January 5, 2026',
        readTime: '4 min read',
        category: 'Meditation',
        published: true,
    },
    {
        id: '3',
        title: 'Yoga Practices for Cultivating Inner Peace',
        slug: 'yoga-for-inner-peace',
        excerpt: 'Explore gentle yoga sequences and breathwork techniques designed to calm the nervous system and invite stillness.',
        content: `# Yoga Practices for Cultivating Inner Peace

Yoga is far more than physical exercise. The word "yoga" comes from the Sanskrit root "yuj," meaning to yoke or unite—signifying the union of individual consciousness with universal consciousness.

## The Eight Limbs of Yoga

Patanjali's Yoga Sutras outline the eight-fold path:

1. **Yama** - Ethical restraints
2. **Niyama** - Personal observances
3. **Asana** - Physical postures
4. **Pranayama** - Breath control
5. **Pratyahara** - Sense withdrawal
6. **Dharana** - Concentration
7. **Dhyana** - Meditation
8. **Samadhi** - Union/Enlightenment

## Gentle Sequence for Peace

### Balasana (Child's Pose)
Rest here for 5 breaths, surrendering to the earth.

### Marjaryasana-Bitilasana (Cat-Cow)
Flow between these for 10 rounds, syncing breath with movement.

### Uttanasana (Standing Forward Fold)
Let your head hang heavy, releasing neck tension.

### Viparita Karani (Legs Up the Wall)
Stay here for 5-10 minutes to calm the nervous system.

### Savasana (Corpse Pose)
Rest in complete stillness for final integration.

Practice with intention, not ambition. The goal is not perfection of form, but cultivation of presence.

🙏 Namaste`,
        author: 'Dinesh',
        date: 'January 1, 2026',
        readTime: '6 min read',
        category: 'Yoga',
        published: true,
    },
];

// Helper function to get posts from localStorage or defaults
export function getPosts(): BlogPost[] {
    if (typeof window === 'undefined') return defaultPosts;

    const stored = localStorage.getItem('answerforself-blog-posts');
    if (stored) {
        try {
            return JSON.parse(stored);
        } catch {
            return defaultPosts;
        }
    }
    return defaultPosts;
}

// Helper to save posts
export function savePosts(posts: BlogPost[]): void {
    if (typeof window === 'undefined') return;
    localStorage.setItem('answerforself-blog-posts', JSON.stringify(posts));
}

// Generate unique ID
export function generateId(): string {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}
