'use client';

import { useState, useEffect } from 'react';
import { getPosts, savePosts, generateId, BlogPost } from '@/lib/blog';
import styles from './admin.module.css';

export default function AdminPage() {
    const [posts, setPosts] = useState<BlogPost[]>([]);
    const [editingPost, setEditingPost] = useState<BlogPost | null>(null);
    const [isCreating, setIsCreating] = useState(false);

    useEffect(() => {
        setPosts(getPosts());
    }, []);

    const createNewPost = () => {
        const newPost: BlogPost = {
            id: generateId(),
            title: '',
            slug: '',
            excerpt: '',
            content: '',
            author: 'Dinesh',
            date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
            readTime: '3 min read',
            category: 'Spirituality',
            published: false,
        };
        setEditingPost(newPost);
        setIsCreating(true);
    };

    const savePost = () => {
        if (!editingPost) return;

        // Generate slug from title if empty
        if (!editingPost.slug) {
            editingPost.slug = editingPost.title
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/(^-|-$)/g, '');
        }

        let updatedPosts: BlogPost[];
        if (isCreating) {
            updatedPosts = [...posts, editingPost];
        } else {
            updatedPosts = posts.map(p => p.id === editingPost.id ? editingPost : p);
        }

        savePosts(updatedPosts);
        setPosts(updatedPosts);
        setEditingPost(null);
        setIsCreating(false);
    };

    const deletePost = (id: string) => {
        if (!confirm('Are you sure you want to delete this post?')) return;
        const updatedPosts = posts.filter(p => p.id !== id);
        savePosts(updatedPosts);
        setPosts(updatedPosts);
    };

    const togglePublish = (id: string) => {
        const updatedPosts = posts.map(p =>
            p.id === id ? { ...p, published: !p.published } : p
        );
        savePosts(updatedPosts);
        setPosts(updatedPosts);
    };

    return (
        <div className={styles.admin}>
            <section className={styles.header}>
                <div className="container">
                    <h1>Blog Admin</h1>
                    <p>Create and manage your blog posts</p>
                </div>
            </section>

            <section className={`section ${styles.content}`}>
                <div className="container">
                    {editingPost ? (
                        <div className={styles.editor}>
                            <h2>{isCreating ? 'Create New Post' : 'Edit Post'}</h2>

                            <div className={styles.formGroup}>
                                <label>Title</label>
                                <input
                                    type="text"
                                    className="form-input"
                                    value={editingPost.title}
                                    onChange={(e) => setEditingPost({ ...editingPost, title: e.target.value })}
                                    placeholder="Post title"
                                />
                            </div>

                            <div className={styles.formRow}>
                                <div className={styles.formGroup}>
                                    <label>Category</label>
                                    <select
                                        className="form-input"
                                        value={editingPost.category}
                                        onChange={(e) => setEditingPost({ ...editingPost, category: e.target.value })}
                                    >
                                        <option value="Vedic Astrology">Vedic Astrology</option>
                                        <option value="Meditation">Meditation</option>
                                        <option value="Yoga">Yoga</option>
                                        <option value="Spirituality">Spirituality</option>
                                        <option value="Ayurveda">Ayurveda</option>
                                    </select>
                                </div>
                                <div className={styles.formGroup}>
                                    <label>Read Time</label>
                                    <input
                                        type="text"
                                        className="form-input"
                                        value={editingPost.readTime}
                                        onChange={(e) => setEditingPost({ ...editingPost, readTime: e.target.value })}
                                        placeholder="5 min read"
                                    />
                                </div>
                            </div>

                            <div className={styles.formGroup}>
                                <label>Excerpt (short description)</label>
                                <textarea
                                    className="form-textarea"
                                    value={editingPost.excerpt}
                                    onChange={(e) => setEditingPost({ ...editingPost, excerpt: e.target.value })}
                                    placeholder="Brief description for the blog list..."
                                    rows={2}
                                />
                            </div>

                            <div className={styles.formGroup}>
                                <label>Content (use # for headings, - for lists)</label>
                                <textarea
                                    className="form-textarea"
                                    value={editingPost.content}
                                    onChange={(e) => setEditingPost({ ...editingPost, content: e.target.value })}
                                    placeholder="Write your blog post content here...

# Main Heading
Your introduction paragraph.

## Subheading
More content here.

- **Bold item** - Description
- Another item"
                                    rows={15}
                                />
                            </div>

                            <div className={styles.formActions}>
                                <button
                                    className="btn btn-secondary"
                                    onClick={() => { setEditingPost(null); setIsCreating(false); }}
                                >
                                    Cancel
                                </button>
                                <button className="btn btn-primary" onClick={savePost}>
                                    {isCreating ? 'Create Post' : 'Save Changes'}
                                </button>
                            </div>
                        </div>
                    ) : (
                        <>
                            <div className={styles.toolbar}>
                                <button className="btn btn-primary" onClick={createNewPost}>
                                    + New Post
                                </button>
                            </div>

                            <div className={styles.postList}>
                                {posts.length === 0 ? (
                                    <p className={styles.empty}>No posts yet. Create your first post!</p>
                                ) : (
                                    posts.map((post) => (
                                        <div key={post.id} className={styles.postItem}>
                                            <div className={styles.postInfo}>
                                                <h3>{post.title || 'Untitled'}</h3>
                                                <div className={styles.postMeta}>
                                                    <span className={styles.category}>{post.category}</span>
                                                    <span>{post.date}</span>
                                                    <span className={post.published ? styles.published : styles.draft}>
                                                        {post.published ? 'Published' : 'Draft'}
                                                    </span>
                                                </div>
                                            </div>
                                            <div className={styles.postActions}>
                                                <button
                                                    className={styles.actionBtn}
                                                    onClick={() => togglePublish(post.id)}
                                                >
                                                    {post.published ? 'Unpublish' : 'Publish'}
                                                </button>
                                                <button
                                                    className={styles.actionBtn}
                                                    onClick={() => { setEditingPost(post); setIsCreating(false); }}
                                                >
                                                    Edit
                                                </button>
                                                <button
                                                    className={`${styles.actionBtn} ${styles.deleteBtn}`}
                                                    onClick={() => deletePost(post.id)}
                                                >
                                                    Delete
                                                </button>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </>
                    )}
                </div>
            </section>
        </div>
    );
}
