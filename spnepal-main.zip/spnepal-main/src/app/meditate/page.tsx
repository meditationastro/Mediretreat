'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import styles from './meditate.module.css';

type Phase = 'inhale' | 'hold' | 'exhale' | 'rest';

const phaseConfig = {
    inhale: { duration: 4, label: 'Breathe In', next: 'hold' as Phase },
    hold: { duration: 4, label: 'Hold', next: 'exhale' as Phase },
    exhale: { duration: 6, label: 'Breathe Out', next: 'rest' as Phase },
    rest: { duration: 2, label: 'Rest', next: 'inhale' as Phase },
};

export default function MeditatePage() {
    const [isActive, setIsActive] = useState(false);
    const [phase, setPhase] = useState<Phase>('inhale');
    const [countdown, setCountdown] = useState(4);
    const [totalTime, setTotalTime] = useState(0);
    const [cycles, setCycles] = useState(0);
    const intervalRef = useRef<NodeJS.Timeout | null>(null);

    const formatTime = (seconds: number) => {
        const mins = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${mins}:${secs.toString().padStart(2, '0')}`;
    };

    const stopExercise = useCallback(() => {
        setIsActive(false);
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
            intervalRef.current = null;
        }
    }, []);

    const startExercise = () => {
        setIsActive(true);
        setPhase('inhale');
        setCountdown(phaseConfig.inhale.duration);
        setTotalTime(0);
        setCycles(0);
    };

    const resetExercise = () => {
        stopExercise();
        setPhase('inhale');
        setCountdown(4);
        setTotalTime(0);
        setCycles(0);
    };

    useEffect(() => {
        if (!isActive) return;

        intervalRef.current = setInterval(() => {
            setTotalTime(prev => prev + 1);

            setCountdown(prev => {
                if (prev <= 1) {
                    const nextPhase = phaseConfig[phase].next;
                    setPhase(nextPhase);

                    if (nextPhase === 'inhale') {
                        setCycles(c => c + 1);
                    }

                    return phaseConfig[nextPhase].duration;
                }
                return prev - 1;
            });
        }, 1000);

        return () => {
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
            }
        };
    }, [isActive, phase]);

    return (
        <div className={styles.meditate}>
            {/* Header */}
            <section className={styles.header}>
                <div className="container">
                    <h1>Breathing Exercise</h1>
                    <p>Find your calm through mindful breathing</p>
                </div>
            </section>

            {/* Exercise Area */}
            <section className={`section ${styles.exerciseSection}`}>
                <div className="container">
                    <div className={styles.exerciseContainer}>
                        {/* Breathing Circle */}
                        <div className={styles.circleWrapper}>
                            <div
                                className={`${styles.breathCircle} ${isActive ? styles[phase] : ''}`}
                            >
                                <div className={styles.circleInner}>
                                    <span className={styles.phaseLabel}>
                                        {isActive ? phaseConfig[phase].label : 'Ready'}
                                    </span>
                                    <span className={styles.countdown}>
                                        {isActive ? countdown : '—'}
                                    </span>
                                </div>
                            </div>

                            {/* Pulse rings */}
                            {isActive && (
                                <>
                                    <div className={`${styles.pulseRing} ${styles.ring1}`}></div>
                                    <div className={`${styles.pulseRing} ${styles.ring2}`}></div>
                                </>
                            )}
                        </div>

                        {/* Stats */}
                        <div className={styles.stats}>
                            <div className={styles.stat}>
                                <span className={styles.statLabel}>Time</span>
                                <span className={styles.statValue}>{formatTime(totalTime)}</span>
                            </div>
                            <div className={styles.stat}>
                                <span className={styles.statLabel}>Cycles</span>
                                <span className={styles.statValue}>{cycles}</span>
                            </div>
                        </div>

                        {/* Controls */}
                        <div className={styles.controls}>
                            {!isActive ? (
                                <button className="btn btn-primary" onClick={startExercise}>
                                    Start Breathing
                                </button>
                            ) : (
                                <>
                                    <button className="btn btn-secondary" onClick={stopExercise}>
                                        Pause
                                    </button>
                                    <button className="btn btn-primary" onClick={resetExercise}>
                                        Reset
                                    </button>
                                </>
                            )}
                        </div>

                        {/* Instructions */}
                        <div className={styles.instructions}>
                            <h3>How to Practice</h3>
                            <div className={styles.steps}>
                                <div className={styles.step}>
                                    <span className={styles.stepNumber}>1</span>
                                    <div>
                                        <strong>Inhale (4s)</strong>
                                        <p>Breathe in slowly through your nose</p>
                                    </div>
                                </div>
                                <div className={styles.step}>
                                    <span className={styles.stepNumber}>2</span>
                                    <div>
                                        <strong>Hold (4s)</strong>
                                        <p>Gently hold your breath</p>
                                    </div>
                                </div>
                                <div className={styles.step}>
                                    <span className={styles.stepNumber}>3</span>
                                    <div>
                                        <strong>Exhale (6s)</strong>
                                        <p>Release slowly through your mouth</p>
                                    </div>
                                </div>
                                <div className={styles.step}>
                                    <span className={styles.stepNumber}>4</span>
                                    <div>
                                        <strong>Rest (2s)</strong>
                                        <p>Pause before the next cycle</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Benefits */}
            <section className={`section ${styles.benefits}`}>
                <div className="container">
                    <h2>Benefits of Conscious Breathing</h2>
                    <div className={styles.benefitsGrid}>
                        <div className={styles.benefitCard}>
                            <span className={styles.benefitIcon}>◯</span>
                            <h3>Calm the Mind</h3>
                            <p>Reduce anxiety and mental chatter through focused breath awareness.</p>
                        </div>
                        <div className={styles.benefitCard}>
                            <span className={styles.benefitIcon}>✧</span>
                            <h3>Balance Energy</h3>
                            <p>Harmonize your prana (life force) and restore inner equilibrium.</p>
                        </div>
                        <div className={styles.benefitCard}>
                            <span className={styles.benefitIcon}>◇</span>
                            <h3>Improve Focus</h3>
                            <p>Enhance concentration and mental clarity for daily activities.</p>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}
