'use client';

import { useState } from 'react';
import styles from './contact.module.css';
import { Reveal } from '../../components/Animations';

export default function ContactPage() {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: ''
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        setFormData(prev => ({
            ...prev,
            [e.target.name]: e.target.value
        }));
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        alert('Thank you for your message. We will get back to you soon!');
    };

    return (
        <div className={styles.contact}>
            {/* Hero */}
            <section className={styles.hero}>
                <div className={styles.heroContent}>
                    <Reveal>
                        <h1>Get in Touch</h1>
                    </Reveal>
                    <Reveal delay={100}>
                        <p>Have questions? We&apos;re here to help you on your meditation journey</p>
                    </Reveal>
                </div>
            </section>

            {/* Contact Section */}
            <section className={styles.contactSection}>
                <div className={styles.inner}>
                    {/* Contact Cards */}
                    <div className={styles.contactCards}>
                        <Reveal delay={200}>
                            <div className={styles.contactCard}>
                                <div className={styles.cardIcon}>✉️</div>
                                <h3>Email Us</h3>
                                <a href="mailto:meditationastro1@gmail.com">meditationastro1@gmail.com</a>
                            </div>
                        </Reveal>
                        <Reveal delay={300}>
                            <div className={styles.contactCard}>
                                <div className={styles.cardIcon}>📱</div>
                                <h3>WhatsApp</h3>
                                <a href="https://wa.me/9779823376110" target="_blank" rel="noopener noreferrer">
                                    +977 982-3376110
                                </a>
                            </div>
                        </Reveal>
                        <Reveal delay={400}>
                            <div className={styles.contactCard}>
                                <div className={styles.cardIcon}>📍</div>
                                <h3>Location</h3>
                                <p>Kathmandu, Nepal</p>
                            </div>
                        </Reveal>
                    </div>

                    {/* Form + Hours Grid */}
                    <div className={styles.formGrid}>
                        <Reveal className={styles.formSection}>
                            <div>
                                <h2>Send Us a Message</h2>
                                <form onSubmit={handleSubmit} className={styles.form}>
                                    <div className={styles.formGroup}>
                                        <label>Name</label>
                                        <input
                                            type="text"
                                            name="name"
                                            value={formData.name}
                                            onChange={handleChange}
                                            placeholder="Your name"
                                        />
                                    </div>
                                    <div className={styles.formGroup}>
                                        <label>Email</label>
                                        <input
                                            type="email"
                                            name="email"
                                            value={formData.email}
                                            onChange={handleChange}
                                            placeholder="your@email.com"
                                        />
                                    </div>
                                    <div className={styles.formGroup}>
                                        <label>Subject</label>
                                        <input
                                            type="text"
                                            name="subject"
                                            value={formData.subject}
                                            onChange={handleChange}
                                            placeholder="How can we help?"
                                        />
                                    </div>
                                    <div className={styles.formGroup}>
                                        <label>Message</label>
                                        <textarea
                                            name="message"
                                            value={formData.message}
                                            onChange={handleChange}
                                            rows={6}
                                            placeholder="Tell us what's on your mind..."
                                        ></textarea>
                                    </div>
                                    <button type="submit" className={styles.submitBtn}>
                                        Send Message
                                    </button>
                                </form>
                            </div>
                        </Reveal>

                        <Reveal className={styles.hoursSection} delay={200}>
                            <div>
                                <h2>Office Hours</h2>
                                <div className={styles.hoursCard}>
                                    <div className={styles.hoursRow}>
                                        <span className={styles.day}>Monday - Friday</span>
                                        <span className={styles.time}>9:00 AM - 8:00 PM</span>
                                    </div>
                                    <div className={styles.hoursRow}>
                                        <span className={styles.day}>Saturday</span>
                                        <span className={styles.time}>10:00 AM - 6:00 PM</span>
                                    </div>
                                    <div className={styles.hoursRow}>
                                        <span className={styles.day}>Sunday</span>
                                        <span className={styles.time}>By appointment</span>
                                    </div>
                                    <p className={styles.timezone}>All times are Nepal Standard Time (NPT)</p>
                                </div>
                            </div>
                        </Reveal>
                    </div>
                </div>
            </section>
        </div>
    );
}
