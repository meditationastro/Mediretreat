import Link from 'next/link';
import styles from './retreats.module.css';

export const metadata = {
    title: 'Retreats | Meditation Astro',
    description: 'Transform your life in the Himalayan mountains with our meditation retreats.',
};

const retreats = [
    { title: '1-Day', location: 'Kathmandu', price: '$80' },
    { title: '3-Day', location: 'Dhulikhel', price: '$280' },
    { title: '7-Day', location: 'Nagarkot', price: '$650' },
    { title: 'Weekend', location: 'Shivapuri', price: '$150' },
];

export default function RetreatsPage() {
    return (
        <div className={styles.retreats}>
            <section className={styles.hero}>
                <div className={styles.heroOverlay}></div>
                <div className={styles.heroContent}>
                    <h1>Meditation Retreats</h1>
                    <p>Transform your life in the Himalayan mountains</p>
                </div>
            </section>

            <section className={styles.retreatsList}>
                <div className={styles.inner}>
                    <div className={styles.grid}>
                        {retreats.map((r, i) => (
                            <div key={i} className={styles.card}>
                                <h3>{r.title} Retreat</h3>
                                <div className={styles.cardDetails}>
                                    <div className={styles.location}>
                                        <span>📍</span> {r.location}
                                    </div>
                                    <div className={styles.price}>{r.price}</div>
                                </div>
                                <Link href="/contact" className={styles.reserveBtn}>
                                    Reserve
                                </Link>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </div>
    );
}
