'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { getPosts, BlogPost } from '@/lib/blog';
import styles from './blog.module.css';

export default function BlogPage() {
    const [posts, setPosts] = useState<BlogPost[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const loadedPosts = getPosts().filter(p => p.published);
        setPosts(loadedPosts);
        setLoading(false);
    }, []);

    if (loading) {
        return (
            <div className={styles.blog}>
                <section className={styles.hero}>
                    <div className="container">
                        <div className={styles.heroContent}>
                            <h1>Blog</h1>
                            <p>Loading...</p>
                        </div>
                    </div>
                </section>
            </div>
        );
    }

    return (
        <div className={styles.blog}>
            {/* Hero */}
            <section className={styles.hero}>
                <div className="container">
                    <div className={styles.heroContent}>
                        <h1>Blog</h1>
                        <p>Insights for your spiritual journey</p>
                    </div>
                </div>
            </section>

            {/* Posts List */}
            <section className={`section ${styles.postsSection}`}>
                <div className="container">
                    <div className={styles.postsList}>
                        {posts.length === 0 ? (
                            <p className={styles.noPosts}>No posts yet. Check back soon!</p>
                        ) : (
                            posts.map((post) => (
                                <article key={post.id} className={styles.postCard}>
                                    <div className={styles.postMeta}>
                                        <span className={styles.postCategory}>{post.category}</span>
                                        <span className={styles.postDate}>{post.date}</span>
                                        <span className={styles.postReadTime}>{post.readTime}</span>
                                    </div>
                                    <h2 className={styles.postTitle}>
                                        <Link href={`/blog/${post.slug}`}>{post.title}</Link>
                                    </h2>
                                    <p className={styles.postExcerpt}>{post.excerpt}</p>
                                    <Link href={`/blog/${post.slug}`} className={styles.readMore}>
                                        Read Article →
                                    </Link>
                                </article>
                            ))
                        )}
                    </div>
                </div>
            </section>
        </div>
    );
}
