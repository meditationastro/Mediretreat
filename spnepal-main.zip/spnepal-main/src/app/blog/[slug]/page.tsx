'use client';

import { useState, useEffect } from 'react';
import { useParams, notFound } from 'next/navigation';
import Link from 'next/link';
import { getPosts, BlogPost } from '@/lib/blog';
import styles from './post.module.css';

export default function BlogPostPage() {
    const params = useParams();
    const [post, setPost] = useState<BlogPost | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const posts = getPosts();
        const found = posts.find(p => p.slug === params.slug && p.published);
        setPost(found || null);
        setLoading(false);
    }, [params.slug]);

    if (loading) {
        return (
            <div className={styles.post}>
                <div className="container">
                    <p>Loading...</p>
                </div>
            </div>
        );
    }

    if (!post) {
        notFound();
    }

    // Simple markdown-like rendering
    const renderContent = (content: string) => {
        return content.split('\n').map((line, i) => {
            if (line.startsWith('# ')) {
                return <h1 key={i} className={styles.h1}>{line.slice(2)}</h1>;
            }
            if (line.startsWith('## ')) {
                return <h2 key={i} className={styles.h2}>{line.slice(3)}</h2>;
            }
            if (line.startsWith('### ')) {
                return <h3 key={i} className={styles.h3}>{line.slice(4)}</h3>;
            }
            if (line.startsWith('- **')) {
                const match = line.match(/- \*\*(.+?)\*\* - (.+)/);
                if (match) {
                    return (
                        <p key={i} className={styles.listItem}>
                            <strong>{match[1]}</strong> — {match[2]}
                        </p>
                    );
                }
            }
            if (line.startsWith('1. ') || line.startsWith('2. ') || line.startsWith('3. ')) {
                return <p key={i} className={styles.listItem}>{line}</p>;
            }
            if (line.trim() === '') {
                return <br key={i} />;
            }
            return <p key={i} className={styles.paragraph}>{line}</p>;
        });
    };

    return (
        <div className={styles.post}>
            {/* Header */}
            <section className={styles.header}>
                <div className="container">
                    <Link href="/blog" className={styles.backLink}>← Back to Blog</Link>
                    <div className={styles.meta}>
                        <span className={styles.category}>{post.category}</span>
                        <span>{post.date}</span>
                        <span>{post.readTime}</span>
                    </div>
                    <h1 className={styles.title}>{post.title}</h1>
                    <p className={styles.author}>By {post.author}</p>
                </div>
            </section>

            {/* Content */}
            <section className={`section ${styles.content}`}>
                <div className="container">
                    <article className={styles.article}>
                        {renderContent(post.content)}
                    </article>
                </div>
            </section>

            {/* CTA */}
            <section className={`section ${styles.cta}`}>
                <div className="container">
                    <div className={styles.ctaContent}>
                        <h2>Ready to Begin Your Journey?</h2>
                        <p>Book a personalized consultation to explore your spiritual path.</p>
                        <Link href="/contact" className="btn btn-primary">
                            Book Appointment
                        </Link>
                    </div>
                </div>
            </section>
        </div>
    );
}
