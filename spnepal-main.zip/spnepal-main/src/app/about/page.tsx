'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import styles from './about.module.css';
import { Reveal, AnimatedNumber } from '../../components/Animations';



export default function AboutPage() {
    const [heroLoaded, setHeroLoaded] = useState(false);
    useEffect(() => { setTimeout(() => setHeroLoaded(true), 100); }, []);

    return (
        <div className={styles.about}>
            {/* Hero */}
            <section className={styles.hero}>
                <div className={styles.heroContent}>
                    <p className={`${styles.heroLabel} ${heroLoaded ? styles.heroEnter1 : ''}`}>About Us</p>
                    <h1 className={`${styles.heroTitle} ${heroLoaded ? styles.heroEnter2 : ''}`}>
                        About <em>Meditation Astro</em>
                    </h1>
                    <p className={`${styles.heroSub} ${heroLoaded ? styles.heroEnter3 : ''}`}>
                        Over a decade of guiding seekers toward inner peace and clarity.
                    </p>
                </div>
            </section>

            {/* Journey */}
            <section className={styles.storySection}>
                <div className={styles.inner}>
                    <div className={styles.storyGrid}>
                        <Reveal direction="left" className={styles.storyImageWrap}>
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img
                                src="https://images.pexels.com/photos/3822621/pexels-photo-3822621.jpeg"
                                alt="Meditation guidance"
                                className={styles.storyImage}
                            />
                        </Reveal>
                        <div className={styles.storyContent}>
                            <Reveal>
                                <p className={styles.sectionLabel}>Our Journey</p>
                            </Reveal>
                            <Reveal delay={80}>
                                <h2>My Journey</h2>
                            </Reveal>
                            <Reveal delay={160}>
                                <p>
                                    With 10+ years of dedicated practice and teaching, I combine traditional Vedic
                                    wisdom with modern mindfulness science. My path began in the Himalayas and has since
                                    guided over 1000 clients across 30+ countries.
                                </p>
                            </Reveal>
                        </div>
                    </div>

                    <div className={`${styles.storyGrid} ${styles.reverse}`}>
                        <div className={styles.storyContent}>
                            <Reveal>
                                <p className={styles.sectionLabel}>Our Approach</p>
                            </Reveal>
                            <Reveal delay={80}>
                                <h2>Philosophy</h2>
                            </Reveal>
                            <Reveal delay={160}>
                                <p>
                                    My approach integrates ancient Buddhist meditation techniques with contemporary
                                    neuroscience to create transformative experiences tailored to each individual&apos;s
                                    unique needs and goals.
                                </p>
                            </Reveal>
                        </div>
                        <Reveal direction="right" className={styles.storyImageWrap}>
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img
                                src="https://images.pexels.com/photos/3807517/pexels-photo-3807517.jpeg"
                                alt="Meditation philosophy"
                                className={styles.storyImage}
                            />
                        </Reveal>
                    </div>
                </div>
            </section>

            {/* Stats */}
            <section className={styles.statsSection}>
                <div className={styles.inner}>
                    <Reveal>
                        <div className={styles.statsGrid}>
                            {[
                                { value: 10, suffix: '+', label: 'Years Experience' },
                                { value: 1000, suffix: '+', label: 'Clients Guided' },
                                { value: 30, suffix: '+', label: 'Countries Reached' },
                                { value: 100, suffix: '%', label: 'Dedicated' },
                            ].map((stat, i) => (
                                <div key={i} className={styles.statCard} style={{ transitionDelay: `${i * 100}ms` }}>
                                    <div className={styles.statValue}>
                                        <AnimatedNumber value={stat.value} suffix={stat.suffix} />
                                    </div>
                                    <div className={styles.statLabel}>{stat.label}</div>
                                </div>
                            ))}
                        </div>
                    </Reveal>
                </div>
            </section>

            {/* CTA */}
            <section className={styles.cta}>
                <div className={styles.ctaInner}>
                    <Reveal>
                        <h2>Ready to Start?</h2>
                    </Reveal>
                    <Reveal delay={120}>
                        <Link href="/contact" className={styles.ctaBtn}>
                            Book Your First Session
                            <span className={styles.btnArrow}>→</span>
                        </Link>
                    </Reveal>
                </div>
            </section>
        </div>
    );
}
