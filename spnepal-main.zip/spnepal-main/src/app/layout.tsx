import type { Metadata } from "next";
import "./globals.css";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import SmoothScroll from "@/components/SmoothScroll";

export const metadata: Metadata = {
  title: "Meditation Astro | Meditation & Spiritual Guidance in Nepal",
  description: "Find inner peace, clarity, and spiritual growth with personalized meditation, mindfulness coaching, and Vedic astrology guidance. Serving Kathmandu and the world.",
  keywords: "meditation, vedic astrology, spiritual guidance, mindfulness, Nepal, Kathmandu, retreats, yoga",
  openGraph: {
    title: "Meditation Astro | Inner Peace & Spiritual Growth",
    description: "Find inner peace, clarity, and spiritual growth with personalized meditation and Vedic astrology guidance.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body suppressHydrationWarning>
        <SmoothScroll />
        <Navigation />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
