'use client';

import Link from 'next/link';
import { useEffect, useRef, useState, useCallback } from 'react';
import styles from './page.module.css';
import SearchInput from '../components/SearchInput';
import { motion } from 'framer-motion';
import { Reveal, useParallax, AnimatedNumber, useScrollReveal, AnimatedHeading, GrowLine } from '../components/Animations';

/* ================================================
   ANIMATION HOOKS (Imported from components/Animations)
   ================================================ */



/* ================================================
   PAGE COMPONENT
   ================================================ */

export default function Home() {
  const [heroLoaded, setHeroLoaded] = useState(false);
  const bannerParallax = useParallax(0.15);
  const aboutImageParallax = useParallax(0.12);

  useEffect(() => {
    // Stagger hero entrance
    const timer = setTimeout(() => setHeroLoaded(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <main className={styles.main}>
      {/* ====== HERO ====== */}
      <section className={styles.hero}>
        {/* Background Image */}
        <div className={styles.heroBgImage}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/logo.png" alt="" />
        </div>

        <div className={styles.heroInner}>
          {/* Animated notification bar */}
          <div className={`${styles.heroBadge} ${heroLoaded ? styles.heroEnter1 : ''}`}>
            <span className={styles.badgeDot} />
            Now accepting new clients worldwide
          </div>

          <h1 className={`${styles.heroTitle} ${heroLoaded ? styles.heroEnter2 : ''}`}>
            Find your{' '}
            <em>inner peace</em>{' '}
            through meditation
          </h1>

          <p className={`${styles.heroSub} ${heroLoaded ? styles.heroEnter3 : ''}`}>
            Personalized meditation coaching, Vedic astrology, and spiritual guidance — serving Kathmandu and clients worldwide.
          </p>

          <div className={`${styles.heroActions} ${heroLoaded ? styles.heroEnter4 : ''}`}>
            <SearchInput
              className={styles.heroOutline}
              icon={
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={styles.searchIcon} aria-hidden="true">
                  <circle cx="11" cy="11" r="8"></circle>
                  <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
              }
            />
            <Link href="/contact" className={styles.heroCta}>
              Book a Session
            </Link>
          </div>

          {/* Stats strip */}
          <div className={`${styles.heroStats} ${heroLoaded ? styles.heroEnter5 : ''}`}>
            {[
              { value: 1000, suffix: '+', label: 'Clients' },
              { value: 30, suffix: '+', label: 'Countries' },
              { value: 10, suffix: '+', label: 'Years' },
            ].map((stat, i) => (
              <div key={i} className={styles.heroStat}>
                <span className={styles.heroStatValue}>
                  <AnimatedNumber value={stat.value} suffix={stat.suffix} />
                </span>
                <span className={styles.heroStatLabel}>{stat.label}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ====== INFO BANNER with parallax ====== */}
      <section className={styles.infoBanner}>
        <motion.div
          ref={bannerParallax.ref}
          className={styles.bannerInner}
          style={{ y: bannerParallax.y }}
        >
          <Reveal>
            <GrowLine />
            <h2 className={styles.bannerTitle}>
              Ancient wisdom meets modern mindfulness. The same techniques, practiced for thousands of years, are now accessible to everyone — online and in-person.
            </h2>
            <GrowLine />
          </Reveal>
        </motion.div>
      </section>

      {/* ====== SERVICES ====== */}
      <section className={styles.servicesSection}>
        <div className={styles.sectionInner}>
          <Reveal>
            <p className={styles.sectionLabel}>Our Services</p>
          </Reveal>
          <Reveal delay={80}>
            <h2 className={styles.sectionTitle}>The proof is in the practice</h2>
          </Reveal>
          <Reveal delay={160}>
            <p className={styles.sectionSub}>
              Compare our personalized programs and find the practice that fits your journey.
            </p>
          </Reveal>

          <div className={styles.servicesGrid}>
            {[
              {
                title: '1:1 Consultation',
                desc: 'One-on-one meditation coaching tailored to your experience level and personal goals.',
                tag: 'Popular',
              },
              {
                title: 'Mindfulness Coaching',
                desc: 'Practical awareness techniques integrated into your daily routine and schedule.',
                tag: 'Online',
              },
              {
                title: 'Vedic Astrology',
                desc: 'Your cosmic blueprint revealed through authentic Jyotish chart readings.',
                tag: 'Reading',
              },
              {
                title: 'Stress Relief',
                desc: 'Specialized breathwork and relaxation programs for anxiety management.',
                tag: 'Wellness',
              },
              {
                title: 'Himalayan Retreats',
                desc: "Multi-day immersive meditation retreats in Nepal's sacred mountain landscapes.",
                tag: 'In-Person',
              },
              {
                title: 'Spiritual Guidance',
                desc: 'Compassionate mentorship for life transitions and soul-level clarity.',
                tag: 'Guidance',
              },
            ].map((service, idx) => (
              <Reveal key={idx} delay={idx * 80}>
                <Link href="/services" className={styles.serviceCard}>
                  <div className={styles.cardTop}>
                    <span className={styles.cardTag}>{service.tag}</span>
                  </div>
                  <h3>{service.title}</h3>
                  <p>{service.desc}</p>
                  <span className={styles.cardArrow}>Learn more</span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ====== ABOUT SECTION ====== */}
      <section className={styles.aboutSection}>
        <div className={styles.sectionInner}>
          <div className={styles.aboutGrid}>
            <div className={styles.aboutContent}>
              <Reveal>
                <p className={styles.sectionLabel}>About</p>
              </Reveal>
              <Reveal delay={80}>
                <h2 className={styles.aboutTitle}>
                  10+ years of <em>dedicated</em> practice and teaching
                </h2>
              </Reveal>
              <Reveal delay={160}>
                <p className={styles.aboutText}>
                  We combine traditional Vedic meditation with contemporary neuroscience, creating transformative experiences tailored to each individual. Over 1,000 clients across 30+ countries.
                </p>
              </Reveal>
              <div className={styles.aboutFeatures}>
                {[
                  'Certified & experienced practitioners',
                  'Sessions available worldwide via Zoom',
                  'In-person retreats in Kathmandu, Nepal',
                  'Personalized for every individual',
                ].map((feat, i) => (
                  <Reveal key={i} delay={240 + i * 60}>
                    <div className={styles.featureItem}>
                      <span className={styles.featureCheck}>✓</span>
                      <span>{feat}</span>
                    </div>
                  </Reveal>
                ))}
              </div>
              <Reveal delay={500}>
                <Link href="/about" className={styles.aboutLink}>
                  Learn more about us <span className={styles.linkArrow}>→</span>
                </Link>
              </Reveal>
            </div>

            <Reveal delay={200} direction="scale" className={styles.aboutImageCol}>
              <motion.div
                ref={aboutImageParallax.ref}
                style={{ y: aboutImageParallax.y }}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="https://images.pexels.com/photos/3822621/pexels-photo-3822621.jpeg"
                  alt="Meditation session"
                  className={styles.aboutImage}
                />
              </motion.div>
            </Reveal>
          </div>
        </div>
      </section>

      {/* ====== TESTIMONIALS ====== */}
      <section className={styles.testimonialsSection}>
        <div className={styles.sectionInner}>
          <Reveal>
            <p className={styles.sectionLabel}>Testimonials</p>
          </Reveal>
          <Reveal delay={80}>
            <h2 className={styles.sectionTitle}>What our clients say</h2>
          </Reveal>

          <div className={styles.testimonialGrid}>
            {[
              {
                name: 'Sarah Mitchell',
                loc: 'United States',
                text: '"I felt calmer after the very first session. The techniques are simple yet profoundly powerful."',
              },
              {
                name: 'Rajesh Sharma',
                loc: 'Kathmandu, Nepal',
                text: '"Clear guidance and practical methods. This has genuinely transformed my life."',
              },
              {
                name: 'Emma Thompson',
                loc: 'United Kingdom',
                text: '"Online sessions fit perfectly into my busy schedule. My anxiety has decreased significantly."',
              },
            ].map((t, i) => (
              <Reveal key={i} delay={i * 120} direction={i === 1 ? 'up' : i === 0 ? 'left' : 'right'}>
                <div className={styles.testimonialCard}>
                  <div className={styles.testimonialStars}>{'★★★★★'}</div>
                  <p className={styles.testimonialText}>{t.text}</p>
                  <div className={styles.testimonialAuthor}>
                    <div className={styles.authorInitial}>{t.name[0]}</div>
                    <div>
                      <div className={styles.authorName}>{t.name}</div>
                      <div className={styles.authorLoc}>{t.loc}</div>
                    </div>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ====== CTA ====== */}
      <section className={styles.ctaSection}>
        <div className={styles.ctaInner}>
          <Reveal>
            <p className={styles.sectionLabel}>Get Started</p>
          </Reveal>
          <Reveal delay={80}>
            <h2 className={styles.ctaTitle}>
              Ready to begin?
            </h2>
          </Reveal>
          <Reveal delay={160}>
            <p className={styles.ctaText}>
              Take the first step. Book a session or reach out on WhatsApp for a free consultation.
            </p>
          </Reveal>
          <Reveal delay={240}>
            <div className={styles.ctaActions}>
              <Link href="/contact" className={styles.ctaPrimary}>
                Book a Session
                <span className={styles.btnArrow}>→</span>
              </Link>
              <a
                href="https://wa.me/9779823376110"
                target="_blank"
                rel="noopener noreferrer"
                className={styles.ctaOutline}
              >
                WhatsApp: +977 982-3376110
              </a>
            </div>
          </Reveal>
        </div>
      </section>
    </main>
  );
}
