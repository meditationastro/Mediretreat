'use client';

import { useState } from 'react';
import Link from 'next/link';
import { products, categories } from '@/lib/products';
import styles from './shop.module.css';

export default function ShopPage() {
    const [activeCategory, setActiveCategory] = useState('All Products');

    const filteredProducts = activeCategory === 'All Products'
        ? products
        : products.filter(p => p.category === activeCategory);

    return (
        <div className={styles.shop}>
            {/* Hero */}
            <section className={styles.hero}>
                <div className="container">
                    <h1>Sacred Products & Tools</h1>
                    <p>Discover our curated collection of spiritual items to enhance your meditation practice, astrological studies, and personal growth journey.</p>
                </div>
            </section>

            {/* Shop Content */}
            <section className={`section ${styles.shopSection}`}>
                <div className="container">
                    <div className={styles.layout}>
                        {/* Categories Sidebar */}
                        <aside className={styles.sidebar}>
                            <h3>Categories</h3>
                            <ul className={styles.categories}>
                                {categories.map(cat => (
                                    <li key={cat}>
                                        <button
                                            className={`${styles.categoryBtn} ${activeCategory === cat ? styles.active : ''}`}
                                            onClick={() => setActiveCategory(cat)}
                                        >
                                            {cat}
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        </aside>

                        {/* Products Grid */}
                        <div className={styles.products}>
                            <div className={styles.productsHeader}>
                                <p>Showing {filteredProducts.length} products</p>
                            </div>

                            <div className={styles.grid}>
                                {filteredProducts.map(product => (
                                    <Link
                                        key={product.id}
                                        href={`/shop/${product.slug}`}
                                        className={styles.productCard}
                                    >
                                        {product.featured && <span className={styles.badge}>Featured</span>}
                                        <div className={styles.productImage}>
                                            <span>{product.image}</span>
                                        </div>
                                        <div className={styles.productInfo}>
                                            <span className={styles.productCategory}>{product.category}</span>
                                            <h4 className={styles.productName}>{product.name}</h4>
                                            <p className={styles.productDescription}>{product.shortDescription}</p>
                                            <div className={styles.productFooter}>
                                                <span className={styles.productPrice}>${product.price}</span>
                                                <span className={styles.viewBtn}>View Details</span>
                                            </div>
                                        </div>
                                    </Link>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* CTA */}
            <section className={`section ${styles.cta}`}>
                <div className="container">
                    <div className={styles.ctaContent}>
                        <h2>Looking for Something Special?</h2>
                        <p>Contact us for custom orders or personalized spiritual tools.</p>
                        <Link href="/contact" className="btn btn-primary">
                            Get in Touch
                        </Link>
                    </div>
                </div>
            </section>
        </div>
    );
}
