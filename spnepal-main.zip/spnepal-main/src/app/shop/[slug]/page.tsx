'use client';

import { useParams, notFound } from 'next/navigation';
import Link from 'next/link';
import { getProductBySlug, getRelatedProducts } from '@/lib/products';
import styles from './product.module.css';

export default function ProductPage() {
    const params = useParams();
    const product = getProductBySlug(params.slug as string);

    if (!product) {
        notFound();
    }

    const relatedProducts = getRelatedProducts(product);

    return (
        <div className={styles.productPage}>
            {/* Breadcrumb */}
            <div className={styles.breadcrumb}>
                <div className="container">
                    <Link href="/shop">← Back to Shop</Link>
                </div>
            </div>

            {/* Product Hero */}
            <section className={styles.productHero}>
                <div className="container">
                    <div className={styles.productGrid}>
                        {/* Image */}
                        <div className={styles.imageSection}>
                            <div className={styles.productImage}>
                                <span>{product.image}</span>
                            </div>
                            {product.featured && <span className={styles.badge}>Featured</span>}
                        </div>

                        {/* Info */}
                        <div className={styles.infoSection}>
                            <span className={styles.category}>{product.category}</span>
                            <h1 className={styles.title}>{product.name}</h1>
                            <p className={styles.price}>${product.price}</p>

                            <p className={styles.shortDesc}>{product.shortDescription}</p>

                            <div className={styles.stockStatus}>
                                {product.inStock ? (
                                    <span className={styles.inStock}>✓ In Stock</span>
                                ) : (
                                    <span className={styles.outOfStock}>Out of Stock</span>
                                )}
                            </div>

                            <div className={styles.actions}>
                                <Link href="/contact" className="btn btn-primary">
                                    Inquire About This Product
                                </Link>
                                <a
                                    href={`https://wa.me/9779823376110?text=I'm interested in: ${product.name}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className={styles.whatsappBtn}
                                >
                                    WhatsApp Us
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Product Details */}
            <section className={`section ${styles.details}`}>
                <div className="container">
                    <div className={styles.detailsGrid}>
                        {/* Description */}
                        <div className={styles.description}>
                            <h2>Description</h2>
                            <div className={styles.descContent}>
                                {product.fullDescription.split('\n\n').map((paragraph, i) => (
                                    <p key={i}>{paragraph}</p>
                                ))}
                            </div>
                        </div>

                        {/* Sidebar */}
                        <div className={styles.sidebar}>
                            {/* Features */}
                            <div className={styles.features}>
                                <h3>Features</h3>
                                <ul>
                                    {product.features.map((feature, i) => (
                                        <li key={i}>
                                            <span className={styles.checkIcon}>✓</span>
                                            {feature}
                                        </li>
                                    ))}
                                </ul>
                            </div>

                            {/* Specifications */}
                            {product.specifications && (
                                <div className={styles.specs}>
                                    <h3>Specifications</h3>
                                    <table>
                                        <tbody>
                                            {product.specifications.map((spec, i) => (
                                                <tr key={i}>
                                                    <td>{spec.label}</td>
                                                    <td>{spec.value}</td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </section>

            {/* Related Products */}
            {relatedProducts.length > 0 && (
                <section className={`section ${styles.related}`}>
                    <div className="container">
                        <h2>Related Products</h2>
                        <div className={styles.relatedGrid}>
                            {relatedProducts.map(item => (
                                <Link
                                    key={item.id}
                                    href={`/shop/${item.slug}`}
                                    className={styles.relatedCard}
                                >
                                    <div className={styles.relatedImage}>
                                        <span>{item.image}</span>
                                    </div>
                                    <h4>{item.name}</h4>
                                    <p className={styles.relatedPrice}>${item.price}</p>
                                </Link>
                            ))}
                        </div>
                    </div>
                </section>
            )}

            {/* CTA */}
            <section className={`section ${styles.cta}`}>
                <div className="container">
                    <div className={styles.ctaContent}>
                        <h2>Questions About This Product?</h2>
                        <p>Contact us for more information or to place a custom order.</p>
                        <Link href="/contact" className="btn btn-primary">
                            Get in Touch
                        </Link>
                    </div>
                </div>
            </section>
        </div>
    );
}
