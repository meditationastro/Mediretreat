'use client';

import Link from 'next/link';
import { useEffect, useRef, useState, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import styles from './services.module.css';
import { Reveal } from '../../components/Animations';



const services = [
    {
        name: '1:1 Consultation',
        image: 'https://images.pexels.com/photos/3807517/pexels-photo-3807517.jpeg',
        desc: 'Personalized guidance for your meditation journey. One-on-one sessions tailored to your experience level.',
        tag: 'Popular',
    },
    {
        name: 'Guided Meditation',
        image: 'https://images.pexels.com/photos/3822621/pexels-photo-3822621.jpeg',
        desc: 'Structured practice sessions for all levels. Learn techniques used for thousands of years.',
        tag: 'In-Person',
    },
    {
        name: 'Stress & Anxiety Relief',
        image: 'https://images.pexels.com/photos/3763418/pexels-photo-3763418.jpeg',
        desc: 'Specialized breathwork and relaxation programs designed to manage anxiety and daily stress.',
        tag: 'Wellness',
    },
    {
        name: 'Vedic Astrology',
        image: 'https://images.pexels.com/photos/1051838/pexels-photo-1051838.jpeg',
        desc: 'Your cosmic blueprint revealed through authentic Jyotish chart readings and analysis.',
        tag: 'Reading',
    },
    {
        name: 'Corporate Sessions',
        image: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg',
        desc: 'Bring mindfulness to your workplace. Group sessions designed for teams and organizations.',
        tag: 'Group',
    },
    {
        name: 'Himalayan Retreats',
        image: 'https://images.pexels.com/photos/2387873/pexels-photo-2387873.jpeg',
        desc: "Multi-day immersive experiences in Nepal's sacred mountain landscapes.",
        tag: 'Retreat',
    },
];

function ServicesContent() {
    const [heroLoaded, setHeroLoaded] = useState(false);
    const searchParams = useSearchParams();
    const query = searchParams.get('q')?.toLowerCase() || '';

    useEffect(() => { setTimeout(() => setHeroLoaded(true), 100); }, []);

    const filteredServices = services.filter(service =>
        service.name.toLowerCase().includes(query) ||
        service.desc.toLowerCase().includes(query) ||
        service.tag.toLowerCase().includes(query)
    );

    return (
        <div className={styles.services}>
            <section className={styles.hero}>
                <div className={styles.heroContent}>
                    <p className={`${styles.heroLabel} ${heroLoaded ? styles.heroEnter1 : ''}`}>What We Offer</p>
                    <h1 className={`${styles.heroTitle} ${heroLoaded ? styles.heroEnter2 : ''}`}>
                        {query ? `Search: "${query}"` : 'Our Services'}
                    </h1>
                    <p className={`${styles.heroSub} ${heroLoaded ? styles.heroEnter3 : ''}`}>
                        {query ? `${filteredServices.length} result(s) found` : 'Personalized meditation and spiritual guidance for your unique path.'}
                    </p>
                </div>
            </section>

            <section className={styles.servicesSection}>
                <div className={styles.inner}>
                    {filteredServices.length > 0 ? (
                        <div className={styles.grid}>
                            {filteredServices.map((service, idx) => (
                                <Reveal key={idx} delay={idx * 100} direction={idx % 2 === 0 ? 'up' : 'scale'}>
                                    <div className={styles.card}>
                                        <div className={styles.cardImageWrap}>
                                            {/* eslint-disable-next-line @next/next/no-img-element */}
                                            <img
                                                src={service.image}
                                                alt={service.name}
                                                className={styles.cardImage}
                                            />
                                            <span className={styles.cardTag}>{service.tag}</span>
                                        </div>
                                        <div className={styles.cardBody}>
                                            <h3>{service.name}</h3>
                                            <p>{service.desc}</p>
                                            <Link href="/contact" className={styles.bookBtn}>
                                                Book Now <span className={styles.btnArrow}>→</span>
                                            </Link>
                                        </div>
                                    </div>
                                </Reveal>
                            ))}
                        </div>
                    ) : (
                        <div style={{ textAlign: 'center', padding: '4rem 0', color: 'var(--text-muted)' }}>
                            <h3>No services found matching &quot;{query}&quot;</h3>
                            <Link href="/services" style={{ marginTop: '1rem', display: 'inline-block', textDecoration: 'underline' }}>
                                View all services
                            </Link>
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
}

export default function ServicesPage() {
    return (
        <Suspense fallback={<div style={{ height: '100vh' }}></div>}>
            <ServicesContent />
        </Suspense>
    );
}
