import styles from './testimonials.module.css';

export const metadata = {
    title: 'Testimonials | Meditation Astro',
    description: 'Real stories from people transformed by meditation.',
};

const testimonials = [
    {
        name: 'Sarah Mitchell',
        location: 'United States',
        text: 'I felt calmer after the first session. The techniques are simple yet powerful. Highly recommended!',
        image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?w=200&h=200',
    },
    {
        name: 'Rajesh Sharma',
        location: 'Kathmandu',
        text: 'Clear guidance and practical methods. This has transformed my life and brought me peace.',
        image: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=200&h=200',
    },
    {
        name: 'Emma Thompson',
        location: 'United Kingdom',
        text: 'The online sessions fit perfectly into my busy schedule. My stress has decreased significantly.',
        image: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?w=200&h=200',
    },
];

export default function TestimonialsPage() {
    return (
        <div className={styles.testimonials}>
            <section className={styles.hero}>
                <div className={styles.heroContent}>
                    <h1>Client Testimonials</h1>
                    <p>Real stories from people transformed by meditation</p>
                </div>
            </section>

            <section className={styles.testimonialsSection}>
                <div className={styles.inner}>
                    <div className={styles.grid}>
                        {testimonials.map((t, i) => (
                            <div key={i} className={styles.card}>
                                <div className={styles.stars}>
                                    {[1, 2, 3, 4, 5].map((x) => (
                                        <span key={x} className={styles.star}>★</span>
                                    ))}
                                </div>
                                <p className={styles.quote}>&ldquo;{t.text}&rdquo;</p>
                                <div className={styles.author}>
                                    {/* eslint-disable-next-line @next/next/no-img-element */}
                                    <img src={t.image} alt={t.name} className={styles.authorImage} />
                                    <div>
                                        <div className={styles.authorName}>{t.name}</div>
                                        <div className={styles.authorLocation}>{t.location}</div>
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        </div>
    );
}
