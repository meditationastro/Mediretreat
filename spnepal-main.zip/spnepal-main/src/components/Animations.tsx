"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform } from "framer-motion";

/* ========================================
   Shared animation hooks & components
   Used across ALL pages for consistency
   ======================================== */

/* Scroll-triggered reveal hook */
export function useScrollReveal(threshold = 0.12) {
    const ref = useRef<HTMLDivElement>(null);
    const [isVisible, setIsVisible] = useState(false);

    useEffect(() => {
        const el = ref.current;
        if (!el) return;

        const observer = new IntersectionObserver(
            ([entry]) => {
                if (entry.isIntersecting) {
                    setIsVisible(true);
                    observer.unobserve(el);
                }
            },
            { threshold, rootMargin: "0px 0px -60px 0px" }
        );
        observer.observe(el);
        return () => observer.disconnect();
    }, [threshold]);

    return { ref, isVisible };
}

/* Reveal wrapper component */
export function Reveal({
    children,
    className = "",
    delay = 0,
    direction = "up",
}: {
    children: React.ReactNode;
    className?: string;
    delay?: number;
    direction?: "up" | "left" | "right" | "scale";
}) {
    const { ref, isVisible } = useScrollReveal(0.12);

    // Map direction to global CSS classes (defined in globals.css)
    const dirClass = `reveal-${direction}`;

    return (
        <div
            ref={ref}
            className={`reveal ${dirClass} ${isVisible ? "revealed" : ""} ${className}`}
            style={{ transitionDelay: `${delay}ms` }}
        >
            {children}
        </div>
    );
}

/* Parallax scroll hook — optimized with framer-motion */
export function useParallax(speed = 0.5) {
    const ref = useRef<HTMLDivElement>(null);
    const { scrollYProgress } = useScroll({
        target: ref,
        offset: ["start end", "end start"],
    });

    const y = useTransform(scrollYProgress, [0, 1], [-200 * speed, 200 * speed]);

    return { ref, y };
}

/* Animated counter for stats */
export function AnimatedNumber({
    value,
    suffix = "",
    duration = 2000,
}: {
    value: number;
    suffix?: string;
    duration?: number;
}) {
    const [count, setCount] = useState(0);
    const { ref, isVisible } = useScrollReveal(0.3);

    useEffect(() => {
        if (!isVisible) return;
        const startTime = performance.now();

        const animate = (now: number) => {
            const elapsed = now - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            setCount(Math.round(eased * value));
            if (progress < 1) requestAnimationFrame(animate);
        };
        requestAnimationFrame(animate);
    }, [isVisible, value, duration]);

    return <span ref={ref}>{count}{suffix}</span>;
}

/* Split text into individually animated words */
export function AnimatedHeading({
    children,
    className = "",
    tag: Tag = "h1",
}: {
    children: string;
    className?: string;
    tag?: "h1" | "h2" | "h3";
}) {
    const { ref, isVisible } = useScrollReveal(0.2);
    const words = children.split(" ");

    return (
        <Tag ref={ref as any} className={`${className} reveal-heading`}>
            {words.map((word, i) => (
                <span key={i} className="reveal-word-wrap">
                    <span
                        className={`reveal-word ${isVisible ? "reveal-word-visible" : ""}`}
                        style={{ transitionDelay: `${i * 80}ms` }}
                    >
                        {word}
                    </span>
                </span>
            ))}
        </Tag>
    );
}

/* Horizontal line that grows on scroll */
export function GrowLine() {
    const { ref, isVisible } = useScrollReveal(0.5);
    return (
        <div ref={ref} className={`grow-line ${isVisible ? "revealed" : ""}`} />
    );
}
