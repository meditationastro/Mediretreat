"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import ServiceTicker from "./ServiceTicker";

export default function SearchInput({
    className,
    icon,
}: {
    className?: string;
    icon?: React.ReactNode;
}) {
    const [query, setQuery] = useState("");
    const [focused, setFocused] = useState(false);
    const router = useRouter();

    const handleSearch = (e: React.FormEvent) => {
        e.preventDefault();
        if (query.trim()) {
            router.push(`/services?q=${encodeURIComponent(query)}`);
        } else {
            router.push("/services");
        }
    };

    return (
        <form
            onSubmit={handleSearch}
            className={className}
            onClick={() => document.getElementById("hero-search-input")?.focus()}
            style={{ cursor: "text" }}
        >
            {icon}
            <div
                style={{
                    position: "relative",
                    flex: 1,
                    display: "flex",
                    alignItems: "center",
                    height: "100%",
                    overflow: "hidden",
                }}
            >
                {/* Ticker Placeholder */}
                {!focused && !query && (
                    <div
                        style={{
                            position: "absolute",
                            left: 0,
                            top: 0,
                            bottom: 0,
                            right: 0,
                            display: "flex",
                            alignItems: "center",
                            pointerEvents: "none",
                            opacity: 0.7,
                        }}
                    >
                        <ServiceTicker />
                    </div>
                )}

                {/* Real Input */}
                <input
                    id="hero-search-input"
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onFocus={() => setFocused(true)}
                    onBlur={() => setFocused(false)}
                    style={{
                        width: "100%",
                        height: "100%",
                        background: "transparent",
                        border: "none",
                        outline: "none",
                        color: "inherit",
                        fontSize: "inherit",
                        fontFamily: "inherit",
                        fontWeight: "inherit",
                        position: "relative",
                        zIndex: 2,
                        padding: 0,
                        margin: 0,
                    }}
                    autoComplete="off"
                />
            </div>
        </form>
    );
}
