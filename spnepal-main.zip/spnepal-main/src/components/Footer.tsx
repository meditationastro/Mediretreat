import Link from 'next/link';
import styles from './Footer.module.css';

const Footer = () => {
    const currentYear = new Date().getFullYear();

    return (
        <footer className={styles.footer}>
            <div className={styles.footerInner}>
                <div className={styles.footerGrid}>
                    {/* Brand */}
                    <div className={styles.brand}>
                        <Link href="/" className={styles.logo}>
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img src="/sitelogo.png" alt="Meditation Astro" className={styles.logoImage} />
                        </Link>
                        <p className={styles.tagline}>
                            Guiding you towards inner peace, clarity, and spiritual growth through meditation,
                            mindfulness, and ancient Vedic wisdom.
                        </p>
                        <div className={styles.socialLinks}>
                            <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className={styles.socialBtn}>
                                FB
                            </a>
                            <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className={styles.socialBtn}>
                                IG
                            </a>
                            <a href="https://youtube.com" target="_blank" rel="noopener noreferrer" className={styles.socialBtn}>
                                YT
                            </a>
                        </div>
                    </div>

                    {/* Quick Links */}
                    <div className={styles.linkGroup}>
                        <h3>Quick Links</h3>
                        <ul>
                            <li><Link href="/about">About Us</Link></li>
                            <li><Link href="/services">Services</Link></li>
                            <li><Link href="/retreats">Retreats</Link></li>
                            <li><Link href="/testimonials">Testimonials</Link></li>
                            <li><Link href="/blog">Blog</Link></li>
                        </ul>
                    </div>

                    {/* Services */}
                    <div className={styles.linkGroup}>
                        <h3>Services</h3>
                        <ul>
                            <li><span>1:1 Meditation Consultation</span></li>
                            <li><span>Guided Meditation</span></li>
                            <li><span>Stress &amp; Anxiety Support</span></li>
                            <li><span>Vedic Astrology</span></li>
                            <li><span>Corporate Sessions</span></li>
                        </ul>
                    </div>

                    {/* Contact */}
                    <div className={styles.linkGroup}>
                        <h3>Contact</h3>
                        <ul className={styles.contactList}>
                            <li>
                                <span className={styles.contactIcon}>📍</span>
                                <span>Kathmandu, Nepal</span>
                            </li>
                            <li>
                                <span className={styles.contactIcon}>✉️</span>
                                <a href="mailto:meditationastro1@gmail.com">meditationastro1@gmail.com</a>
                            </li>
                            <li>
                                <span className={styles.contactIcon}>📱</span>
                                <a href="https://wa.me/9779823376110">WhatsApp: +977 982-3376110</a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div className={styles.bottom}>
                    <p>
                        © {currentYear} Meditation Astro. All rights reserved.
                        <span className={styles.dot}>•</span>
                        Serving Nepal and the World
                    </p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
