"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const services = [
    "Meditation Coaching",
    "Vedic Astrology",
    "Spiritual Guidance",
    "Wellness Retreats",
    "Chakra Healing",
    "Mindfulness",
];

export default function ServiceTicker() {
    const [index, setIndex] = useState(0);

    useEffect(() => {
        const timer = setInterval(() => {
            setIndex((prev) => (prev + 1) % services.length);
        }, 3000);
        return () => clearInterval(timer);
    }, []);

    return (
        <div style={{ position: "relative", height: "2rem", overflow: "hidden", display: "inline-block", width: "100%", verticalAlign: "middle", textAlign: "left" }}>
            <AnimatePresence mode="popLayout">
                <motion.span
                    key={index}
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: -20, opacity: 0 }}
                    transition={{ duration: 0.5, ease: "easeInOut" }}
                    style={{ position: "absolute", left: 0, top: "50%", marginTop: "-0.5em", whiteSpace: "nowrap", width: "100%", lineHeight: 1 }}
                >
                    Try "{services[index]}"
                </motion.span>
            </AnimatePresence>
        </div>
    );
}
