'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import styles from './Navigation.module.css';

const Navigation = () => {
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
    const [headerVisible, setHeaderVisible] = useState(true);
    const [lastScrollY, setLastScrollY] = useState(0);
    const pathname = usePathname();

    useEffect(() => {
        let ticking = false;
        const handleScroll = () => {
            if (!ticking) {
                requestAnimationFrame(() => {
                    const currentScrollY = window.scrollY;
                    setIsScrolled(currentScrollY > 40);

                    // Hide/show header on scroll direction
                    if (currentScrollY > 300) {
                        setHeaderVisible(currentScrollY < lastScrollY || currentScrollY < 100);
                    } else {
                        setHeaderVisible(true);
                    }
                    setLastScrollY(currentScrollY);
                    ticking = false;
                });
                ticking = true;
            }
        };

        window.addEventListener('scroll', handleScroll, { passive: true });
        return () => window.removeEventListener('scroll', handleScroll);
    }, [lastScrollY]);

    // Close mobile menu on route change
    useEffect(() => {
        setIsMobileMenuOpen(false);
    }, [pathname]);

    // Prevent body scroll when mobile menu is open
    useEffect(() => {
        if (isMobileMenuOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = '';
        }
        return () => { document.body.style.overflow = ''; };
    }, [isMobileMenuOpen]);

    const isActive = (path: string) => pathname === path;

    const navLinks = [
        { href: '/', label: 'Home' },
        { href: '/about', label: 'About' },
        { href: '/services', label: 'Services' },
        { href: '/retreats', label: 'Retreats' },
        { href: '/testimonials', label: 'Testimonials' },
        { href: '/blog', label: 'Blog' },
        { href: '/contact', label: 'Contact' },
    ];

    return (
        <header
            className={`${styles.header} ${isScrolled ? styles.scrolled : ''} ${!headerVisible ? styles.headerHidden : ''
                }`}
        >
            <div className={styles.headerInner}>
                <div className={styles.headerContent}>
                    <Link href="/" className={styles.logo}>
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img src="/sitelogo.png" alt="Meditation Astro" className={styles.logoImage} />
                    </Link>

                    <nav className={styles.desktopNav}>
                        {navLinks.map((link, i) => (
                            <Link
                                key={link.href}
                                href={link.href}
                                className={`${styles.navLink} ${isActive(link.href) ? styles.navLinkActive : ''}`}
                                style={{ animationDelay: `${i * 50}ms` }}
                            >
                                {link.label}
                                {isActive(link.href) && <div className={styles.activeBar}></div>}
                            </Link>
                        ))}
                    </nav>

                    <div className={styles.desktopCta}>
                        <Link href="/contact" className={styles.bookBtn}>
                            Book Session
                        </Link>
                    </div>

                    <button
                        className={`${styles.mobileToggle} ${isMobileMenuOpen ? styles.active : ''}`}
                        onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                        aria-label="Toggle menu"
                    >
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                </div>
            </div>

            {/* Mobile menu — always in DOM, animated via CSS */}
            <div className={`${styles.mobileMenu} ${isMobileMenuOpen ? styles.mobileMenuOpen : ''}`}>
                <nav className={styles.mobileNav}>
                    {navLinks.map((link, i) => (
                        <Link
                            key={link.href}
                            href={link.href}
                            onClick={() => setIsMobileMenuOpen(false)}
                            className={`${styles.mobileLink} ${isActive(link.href) ? styles.mobileLinkActive : ''}`}
                            style={{
                                transitionDelay: isMobileMenuOpen ? `${i * 60 + 100}ms` : '0ms',
                            }}
                        >
                            {link.label}
                        </Link>
                    ))}
                    <Link
                        href="/contact"
                        onClick={() => setIsMobileMenuOpen(false)}
                        className={styles.mobileBookBtn}
                        style={{
                            transitionDelay: isMobileMenuOpen ? `${navLinks.length * 60 + 100}ms` : '0ms',
                        }}
                    >
                        Book Session
                    </Link>
                </nav>
            </div>
        </header>
    );
};

export default Navigation;
